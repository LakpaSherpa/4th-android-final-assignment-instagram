#include "Buzzer.h"

Buzzer::Buzzer(const int pin) : Switchable(pin)
{
    
}
